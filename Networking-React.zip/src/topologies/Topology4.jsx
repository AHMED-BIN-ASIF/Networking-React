import React from 'react'
import Header from '../components/Header'

const Topology4 = () => {
  return (
    <div>
      <Header title='Simple Topology 4' />
    </div>
  )
}

export default Topology4
