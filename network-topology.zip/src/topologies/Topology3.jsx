import React from 'react'
import Header from '../components/Header'

const Topology3 = () => {
  return (
    <div>
      <Header title='Simple Topology 3' />
    </div>
  )
}

export default Topology3
