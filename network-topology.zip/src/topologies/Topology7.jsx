import React from 'react'
import Header from '../components/Header'

const Topology7 = () => {
  return (
    <div>
      <Header title='Simple Topology 7' />
    </div>
  )
}

export default Topology7
