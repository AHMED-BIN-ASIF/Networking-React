import React from 'react'
import Header from '../components/Header'

const Topology6 = () => {
  return (
    <div>
      <Header title='Simple Topology 6' />
    </div>
  )
}

export default Topology6
