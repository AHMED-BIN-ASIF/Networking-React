import React from 'react'
import Header from '../components/Header'

const Topology5 = () => {
  return (
    <div>
      <Header title='Simple Topology 5' />
    </div>
  )
}

export default Topology5
